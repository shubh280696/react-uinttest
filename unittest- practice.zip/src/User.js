import React from "react";

export default  class User extends React .Component{

getUserList(a){
    return a ;
}
render(){
    return(
        <div>
            <h2>user class component</h2>
            <button onClick={()=>this.setState()}>userData</button>
        </div>
    )
}

}